---
title: 202210141110 - Programador Produtivo
tags: #permanentes 
---

# 202210141110 - Programador Produtivo

Ultimamente tenho me sentido incomodado com o tempo que levo para finalizar meus projetos e tarefas. Por conta disso, tenho olhado para minha rotina e buscado formas de melhorar ela.

Hoje, quero compartilhar alguns pontos de melhoria que tem me ajudado, e acredito que possam te ajudar também. 

## 🤔 Entenda o projeto ou problema que você está resolvendo
Como desenvolvedores, adoramos criar coisas. Partimos para o código, antes de entendermos profundamente que deve ser feito. 

Segure essa vontade. Certifique-se de ter entendido tudo. Repita o que ouviu e entendeu para garantir o alinhamento.

Você pode utilizar afirmações, por exemplo: "Entendi que, você espera que este elemento se comporte dessa forma, quando determinado evento acontecer. "

Caso algo tenha passado despercebido, agora poderá ser resolvido e todos estarão na mesma página.

## ✔ Resolva apenas o problema que foi definido 
Durante o desenvolvimento é muito fácil enxergarmos oportunidades de novas soluções para serem feitas, e outros problemas a serem explorados. 

Tome cuidado, e ignore tudo o que não foi definido para ser feito. Não atrase a entrega combinada. Caso sinta que a tarefa é importante, anote e deixe para resolver depois. Mantenha o foco.

## 📌Quebre o problema em pedaços menores
Se você não entender o que deve ser feito, por ser um problema grande demais, quebre ele em pedaços menores e isole um para ser resolvido.

Com isso, você terá mais clareza do que deve ser feito, e qual a melhor forma de fazê-lo. A sobrecarga e complexidade da tarefa diminui, removendo também o medo de começar.

## ❤ Seus melhores amigos: teclado, terminal e IDE
Aprender a digitar rápido é super importante. Sua produtividade dobrará se manter suas mãos em cima do teclado e evitar usar o mouse.

Domine os atalhos de teclado da sua IDE. Se possível, aprenda como utilizar o VIM. Você pode ativar ele na sua IDE preferida com alguma extensão.

Crie atalhos no seu terminal para rotinas e comandos que você utiliza diariamente. Um comando de quinze palavras, pode ser digitado em duas, e isso vai te trazer uma produtividade enorme.

## 🖌 Programar é uma arte, então pense como um artista
Foque no que deve ser entregue e deixe os detalhes para o final. A parte mais importante é resolver o problema, é fazer funcionar. 

Assim como um artista que começa pelo esboço e aplica os detalhes no final. Comece pelo rascunho onde é mais fácil, não se prenda aos detalhes ainda. Se perder tempo demais nos detalhes, o projeto pode atrasar. 

Faça funcionar da forma mais simples possível primeiro, depois foque nos detalhes como usabilidade, etc.

## 🎯 Defina um objetivo
Olhe para sua rotina, e pense em uma única coisa que você poderia melhorar e que teria um grande impacto se evoluísse nisso.

Defina um prazo de evolução e pratique. Exemplo: em três meses quero estar digitando no dobro da velocidade em que digito hoje.

Lembre-se, não precisa melhorar tudo de uma vez. Um passo de cada vez é melhor que ficar parado.

### Links relacionados:
- UP: [[Home]]
- [[Programação]]
- [[202210141110 - Como ser um programador produtivo]]