---
title: 202210291223 - Para você que quer começar a desenvolver, mas está com medo
tags: #permanentes 
---

# 202210291223 - Para você que quer começar a desenvolver, mas está com medo

Eu entendo que pensar em entrar na área de desenvolvimento, ou tecnologia em geral, pode criar uma sobrecarga e te fazer desistir, sem nem mesmo tentar. Com isso em mente, esse conteúdo é para te ajudar.

Para começar, precisamos entender a diferença entre quatro palavras que por várias vezes se misturam, mas ao saber diferenciar pode facilitar o seu início na área e te motivar ao aprendizado. 

### Diferença entre emprego, carreira, vocação e hobby.

- **Emprego**: é o único que você precisa ter por obrigação. Afinal, você precisa pagar suas contas, sua independência e manter seu estilo de vida.
  
  Se você não amar o seu emprego, tudo bem! Ele não precisa ser o melhor do mundo, precisa apenas te pagar. Você entrega o seu tempo e recebe algo em troca. Agora se estiver te matando, sendo abusivo, manipulativo e tóxico, mude o mais rápido possível.

- **Carreira**: não é obrigatória, mas se decidir ter, você precisa amar sua carreira. É algo que você está disposto a fazer sacrifícios, fazer hora extra, estudar e trabalhar aos finais de semana, colocar ela a frente de outras coisas importantes na sua vida, por ser uma missão que você acredita profundamente.
  
  Tudo bem não gostar do seu emprego, mas ter uma carreira pela qual você não é apaixonado é errado. 

- **Hobby**: é algo que você faz apenas por prazer e diversão. Para lembrar que a vida não é apenas trabalho e contas para pagar. 
  
  Ninguém precisa saber sobre o seu hobby, você não precisa ganhar dinheiro com ele, ficar famoso, nem precisa ser bom, e os riscos caso desista ou mude de hobby, é zero!
  
  Não é obrigatório, mas é bom ter.

- **Vocação**: É a sua contribuição ao mundo para torná-lo um lugar melhor. Algo que preenche o seu coração e te motiva, que você poderia facilmente fazer de graça. Ninguém pode tirá-la de você. Você pode perder seu emprego e carreira, mas não sua vocação.

Você pode começar a desenvolver coisas como um hobby, enquanto trabalha em um emprego normal. E se você sentir que essa é uma área que você é apaixonado, persiga como uma carreira. Quem sabe sua vocação seja ensinar, e você consiga misturar tudo como uma coisa só? Do mesmo jeito que estou tentando fazer aqui. Seria incrível.

### Saiba onde você quer chegar
Escolher um caminho é difícil, mas é importante. O que nós não sabemos é que está tudo bem mudar e decidir seguir e fazer escolhas para caminhos diferentes. Isso ajuda na busca pelo que nos interessa mais. 

Nenhuma experiência é um fracasso: elas servem de aprendizado e irão refletir em você como pessoa, te tornando profissional melhor na área que você decidir escolher.

Então, escolha um caminho e siga. O importante é você se manter em movimento, e com o tempo decidir onde você quer chegar.

### Procure as pessoas que podem te ajudar a alcançar seus objetivos
Agora que já encontrou um caminho para seguir e tem um objetivo, procure pelas pessoas que podem te ajudar a alcançar e chegar onde você quer. Ninguém consegue vencer sozinho. Todo mundo precisa de alguém. 

Onde essas pessoas estão? Elas podem estar dentro de uma comunidade no Discord, Facebook ou Linkedin. Talvez em eventos que acontecem na sua cidade. O importante é se conectar com elas.

### Descubra como você pode ajudar essas pessoas a alcançar os objetivos delas
Uma forma de você conseguir o que quer de outras pessoas, é ajudando elas a conseguirem o que elas querem, criando uma relação saudável de troca de experiências.

Mesmo que você acredite que não tenha nada para contribuir, existe sempre alguma coisa que você sabe mais que alguém, e que pode agregar valor. Compartilhe!

### Seja apaixonado por criar e mostre para o mundo
É incrível ver o brilho nos olhos das pessoas quando elas mostram e falam das coisas que elas fazem e amam. 

Não espere por projetos chegarem até você, crie uns de estudo, compartilhe seus medos e desafios sobre eles. Seja sincero a respeito. Fale do processo, do que você aprendeu e como poderia melhorar. 

Coloquem eles onde as pessoas possam ver, se ninguém puder vê-los, não faz sentido criá-los. Caso não goste do resultado dos seus projetos, crie mais coisas.

### Não desista
Seus projetos no começo não serão tão bons, principalmente se você se comparar com o trabalho de outras pessoas. Por conta disso, irá pensar que não é bom o suficiente, e que aquilo não é para você. 

Mas isso é só o processo de aprendizado. Se permita aprender, pois você precisará criar vários projetos para que os bons comecem a aparecer. Vai ter momentos em que você se cobrará demais, mas ao olhar para trás verá o tanto que evoluiu, e o quão longe você chegou. Você só precisa da experiência.


### Links relacionados:
- UP: [[Home]]
- [[202210181451 - Conselhos para jovens criadores]]
- [[202210181540 - Distinção entre hobbies, empregos, carreira e vocação]]